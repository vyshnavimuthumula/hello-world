package com.cg.bank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bank.bean.Bank;
import com.cg.bank.exception.BankException;
import com.cg.bank.service.IBankService;

@RestController
public class BankController {

	@Autowired
	IBankService bankService;
	
	@RequestMapping(value="/bank",method=RequestMethod.POST)
	public List<Bank> addBank(@RequestBody Bank bank) throws BankException{
		return bankService.addBank(bank);
	}
	@RequestMapping("/bank")
	public List<Bank> getBankDetails() throws BankException{
		return bankService.getAllBankDetials();
	}
	
	@RequestMapping("/bank/accountnum")
	public Bank getBankDetailsByAccountnum(@RequestParam String accountnum) throws BankException{
		return bankService.getBankDetailsByAccountnum(accountnum);
	}
	
}
