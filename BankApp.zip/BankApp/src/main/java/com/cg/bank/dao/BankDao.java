package com.cg.bank.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.bank.bean.Bank;

@Repository
public interface BankDao extends JpaRepository<Bank, Double>{

	@Query("from Bank where accountnum=:accountnum")
	List<Bank> getBankDetailsByAccountnum(String accountnum);
}
