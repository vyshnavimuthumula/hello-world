package com.cg.bank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bank.bean.Bank;
import com.cg.bank.dao.BankDao;
import com.cg.bank.exception.BankException;


@Service
public class BankService implements IBankService{

	@Autowired
	BankDao bankDao;
	@Override
	public List<Bank> addBank(Bank bankcustomer) throws BankException {
	try {
		bankDao.save(bankcustomer);
		return bankDao.findAll();
	}catch(Exception e) {
		throw new BankException(e.getMessage());
	}
	}

	@Override
	public List<Bank> getAllBankDetials() throws BankException {
		try {
			return bankDao.findAll();
		}catch(Exception e) {
			throw new BankException(e.getMessage());
		}
	}

	@Override
	public Bank getBankDetailsByAccountnum(String accountnum) throws BankException {
		try {
			return (Bank) bankDao.getBankDetailsByAccountnum(accountnum);
		}catch(Exception e) {
			throw new BankException(e.getMessage());
		}
	}
		

}
