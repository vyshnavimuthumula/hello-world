package com.cg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

import com.cg.bean.Bank;
import com.cg.bean.Transaction;

public class DataStorage {
	Transaction transBean=new Transaction();
	HashMap<Long, Bank> hm1=new HashMap<Long, Bank>();
    String URL= "JDBC:oracle:thin:@localhost:1521:XE";
    public Connection establishconn() {
    	Connection connect=null;
    	try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	try {
			 connect =DriverManager.getConnection(URL,"system","orcl11g");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    return connect;
    }
   public void createAccount(Bank bankBean) {
	   Connection con=establishconn();
	   int result=0;
	try {
		PreparedStatement stat= con.prepareStatement("insert into BankDet values(?,?,?,?,?,?)");
		PreparedStatement state=con.prepareStatement("insert into Transactions values(?,?,?,?,?)");
		
		stat.setString(1,bankBean.getName());
		stat.setString(2, bankBean.getDob());
	    stat.setLong(3,bankBean.getPhoneno());
	    stat.setLong(4,bankBean.getBal());
		stat.setLong(5,bankBean.getBacc());
		stat.setString(6,bankBean.getPassword());
        result= stat.executeUpdate();
        System.out.println(result);
        System.out.println(stat);
        
        state.setLong(1,transBean.getTransid());
        state.setLong(2, 0);
        state.setLong(3, 0);
        state.setLong(4,transBean.getAmount());
        state.setLong(5,transBean.getAccountnumber());
        state.executeQuery();

	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    

   }
   public long showBal(long bacc) {
	   Connection con=establishconn();
	   long result=0;
		try {
			PreparedStatement stat= con.prepareStatement("select Balance from BankDet where BAcc=?");
			stat.setLong(1,bacc);
	        ResultSet rs= stat.executeQuery();
	        while(rs.next()) {
	        	result=rs.getLong("Balance");
	        }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return result ;
    }
   
   public long depositAmount(long accountNo, long Amount1) {
	   Connection con=establishconn();
	   long deposit=0;
		try {
			long amount=showBal(accountNo)+Amount1;
			PreparedStatement stat= con.prepareStatement("update BankDet set Balance=? where BAcc=?");
			PreparedStatement state=con.prepareStatement("insert into Transactions values(?,?,?,?,?)");			
			stat.setLong(1,amount);
			stat.setLong(2,accountNo);
			stat.executeQuery();
	            deposit=showBal(accountNo);	            
	            state.setLong(1,transBean.getTransid());
	            state.setLong(2, transBean.getAmount());
	            state.setLong(3, 0);
	            state.setLong(4,transBean.getAmountrecieved());
	            state.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
       return deposit;
   }
   public long withdraw(long accountNo, long Amount1) {
	   Connection con=establishconn();
	   long amount=showBal(accountNo)-Amount1;
	   long withdraw=0;
		try {
			PreparedStatement stat= con.prepareStatement("update BankDet set Balance=? where BAcc=?");
			 stat.setLong(1,amount);
				stat.setLong(2,accountNo);
				stat.executeQuery();
               withdraw=showBal(accountNo);
     
	    } catch (SQLException e) {
			e.printStackTrace();
		}
		return withdraw;
   }
   public void cashTransfer(long source, long destination, long money) {
	   Connection con=establishconn();
	   long amount=showBal(source)-money;
	  
		try {
			PreparedStatement stat= con.prepareStatement("update BankDet set Balance=? where BAcc=?");
			stat.setLong(1, amount);
			stat.setLong(2, source);
			stat.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		  long amount1=showBal(destination)+money;
			try {
				PreparedStatement stat= con.prepareStatement("update BankDet set Balance=? where BAcc=?");
				stat.setLong(1,amount1);
				stat.setLong(2, destination);
				 stat.executeQuery();
			} catch (SQLException e) {
				e.printStackTrace();
			}
 }
   public ResultSet getAllTransactions(long accountNumber) {
	   ResultSet rs=null;  
	   Connection con=establishconn();
		try {
			PreparedStatement stat= con.prepareStatement("select * from Transactions where BAcc=?");
			  stat.setLong(1, accountNumber);             
			  rs=stat.executeQuery();   
		} catch (SQLException e) {
			e.printStackTrace();
		}
       return rs;
   }
  }

