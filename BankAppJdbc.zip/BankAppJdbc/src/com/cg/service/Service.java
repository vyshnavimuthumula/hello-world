package com.cg.service;

import java.sql.ResultSet;
import java.util.List;

import com.cg.bean.Bank;
import com.cg.dao.DataStorage;

public class Service {

	DataStorage data=new DataStorage();
	public void service(Bank b) {
	 
		data.createAccount(b);
  }

 public long showbalance(long bacc,String password1) {
		return data.showBal(bacc);
	}

	public  long deposit(long accountNo, String password2, long Amount) {
		return data.depositAmount(accountNo, Amount);
	}	

  public long withdraw(long account3, String password3, long Amount1) 
	{
	   return data.withdraw(account3, Amount1);
	}
	public void fund(long sour,  long dest,String password4,long amount2) 
	{
		data.cashTransfer(sour, dest, amount2);
	}

	public ResultSet getTransactions(long accountNumber) { 
		return data.getAllTransactions(accountNumber);
	}
}
