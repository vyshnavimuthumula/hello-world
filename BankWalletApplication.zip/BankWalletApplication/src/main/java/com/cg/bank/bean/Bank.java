package com.cg.bank.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Bank {

	@Id
	@SequenceGenerator(name="bankId",sequenceName="bank_seq",allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="bankId")
	
	private int accountnum;
	private String name;
	private String phonenum;
	private String adharnum;
	private int pin;
	private int balance;
	//private int amount;
	
	private String username;
	private String password;
//	
	
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getAccountnum() {
		return accountnum;
	}
	
	public void setAccountnum(int accountnum) {
		this.accountnum = accountnum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhonenum() {
		return phonenum;
	}
	public void setPhonenum(String phonenum) {
		this.phonenum = phonenum;
	}
	public String getAdharnum() {
		return adharnum;
	}
	public void setAdharnum(String adharnum) {
		this.adharnum = adharnum;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Bank [accountnum=" + accountnum + ", name=" + name + ", phonenum=" + phonenum + ", adharnum=" + adharnum
				+ ", pin=" + pin + ", balance=" + balance + "]";
	}
	
	
}
