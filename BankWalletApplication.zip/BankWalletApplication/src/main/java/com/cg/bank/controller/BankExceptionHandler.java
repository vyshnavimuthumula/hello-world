package com.cg.bank.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.bank.exception.BankException;




@ControllerAdvice
public class BankExceptionHandler {

	@ExceptionHandler(BankException.class)
	public ResponseEntity<String> handleException(Exception ex){
		return new ResponseEntity<String>("Error: " + ex.getMessage(),HttpStatus.CONFLICT);
		
	}
}
