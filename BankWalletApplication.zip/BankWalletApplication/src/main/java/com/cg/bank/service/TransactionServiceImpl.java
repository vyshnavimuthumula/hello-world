package com.cg.bank.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bank.bean.Transaction;
import com.cg.bank.dao.TransactionDao;

@Service
public class TransactionServiceImpl implements TransactionService{
	
	@Autowired	
    TransactionDao transactionDatabase;

    @Override
    public void addTransaction(String msg, int accnum) {
        int id = (int) Math.ceil((Math.random()*1000));
        Transaction trans = new Transaction(id, accnum, msg);
        transactionDatabase.save(trans);
    }
    @Override
    public List<String> getTransaction(int id) {
        List<Transaction> list = transactionDatabase.findAll();
        List<String> showList = new ArrayList<String>();
        for(Transaction trans: list) {
            if(trans.getAccnum() == id) {
            	showList.add(trans.getMsg());
            }
        }
        return showList;
        
    }
    }
 
