package com.cd.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.bean.Bank;
import com.cg.bean.Transaction;


public class DataStorage {
	
	static List<Bank> list=new ArrayList<Bank>();
	static List<Transaction> trasactionlist=new ArrayList<Transaction>();
	
	//Storing the data
	public void storeCustomerDetails(Bank bank) {
		list.add(bank);		
		
	}
	
	//Displaying the data
	public List<Bank> getCustomerDetails() {
		return list;
	}
	
	//Displaying the deposited data
	
	public void storeTransactionDetails(Transaction transaction) {
		trasactionlist.add(transaction);		
		
	}
	
}
