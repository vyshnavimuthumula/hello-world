import { Component, OnInit } from '@angular/core';
import {NgForm} from '@angular/forms'
import { HttpClient } from '@angular/common/http';
import { HttpClientService} from '../service/http-client.service';
import { Bank } from '../ibank';
@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.css']
})
export class CreateAccountComponent implements OnInit {
  
  user: Bank = new Bank();
  constructor(private httpClientService:HttpClientService) { }

  ngOnInit() {
    
  }
  createBankAccount(name,phonenum,accountnum,pin,adharnum,balance): void {
    this.user.name=name;
    this.user.phonenum=phonenum;
    this.user.accountnum=accountnum;
    this.user.pin=pin;
    this.user.adharnum=adharnum;
    this.user.balance=balance;
    this.httpClientService.createBankAccount(this.user)
    .subscribe( data => {
    alert("Account created successfully.");
    });
}
}
