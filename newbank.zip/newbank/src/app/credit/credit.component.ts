import { Component, OnInit } from '@angular/core';
import { HttpClientService } from '../service/http-client.service';

@Component({
  selector: 'app-credit',
  templateUrl: './credit.component.html',
  styleUrls: ['./credit.component.css']
})
export class CreditComponent implements OnInit {

  amount: number;
  constructor(private httpClientService:HttpClientService) { }
  ngOnInit() {
  }

 credit(accountnum,creditedmoney){
   this.httpClientService.creditedMoney(accountnum,creditedmoney).subscribe(data => {
   this.amount = data;
   this.httpClientService.setAccountNum(accountnum);
 });

}


}
