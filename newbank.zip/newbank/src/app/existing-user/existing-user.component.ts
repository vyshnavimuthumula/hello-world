import { Component, OnInit } from '@angular/core';
import { Bank } from '../ibank';
import { HttpClientService } from '../service/http-client.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-existing-user',
  templateUrl: './existing-user.component.html',
  styleUrls: ['./existing-user.component.css']
})
export class ExistingUserComponent implements OnInit {

  temp = new Bank();
  Bank = new Bank();
  constructor(private httpClientService:HttpClientService,public router:Router) { }

  ngOnInit() {
  }
  login(username,password){
  this.httpClientService.login(username,password).subscribe(data=>{
    this.temp=data;
    this.httpClientService.setBank(this.temp);
    this.router.navigate(['/maindetails']);
  },error=>alert("Details invalid, please try again")
  );
}
}