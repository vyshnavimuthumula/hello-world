import { Component, OnInit } from '@angular/core';
import { HttpClientService} from '../service/http-client.service';
@Component({
  selector: 'app-show-balance',
  templateUrl: './show-balance.component.html',
  styleUrls: ['./show-balance.component.css']
})
export class ShowBalanceComponent implements OnInit {
  bank: any; 
  balance:number;
  constructor(private httpClientService:HttpClientService) { }
  ngOnInit() {
  }
 showCustBalance(){
   const accountnum=(document.getElementById('accountnum') as HTMLInputElement).value;
   this.httpClientService.showBalance(accountnum).subscribe(response=>this.handleSuccessfulResponse(response));
   console.log("response");
 }

   handleSuccessfulResponse(response){
     this.bank=response;
     console.log(this.bank);
   }
}
